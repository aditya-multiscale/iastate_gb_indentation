| index | Indents | Distinct indented grains |
|---|---|---|
| LAGB / All | 22 | 22 |
| HAGB / Cube | 62 | 49 |
| HAGB / Goss | 60 | 50 |
| HAGB / Brass | 72 | 57 |
| HAGB / All | 194 | 156 |